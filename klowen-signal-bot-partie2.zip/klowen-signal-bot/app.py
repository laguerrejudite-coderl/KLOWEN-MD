"""KLOWEN SIGNAL BOT : tableau de bord Streamlit.  Lancement : streamlit run app.py"""
from __future__ import annotations

import logging

import pandas as pd
import streamlit as st

from backtesting.engine import BacktestConfig, run_backtest
from config.settings import DEFAULT_SYMBOLS, SUPPORTED_INTERVALS, configure_logging, load_settings
from dashboard.charts import equity_chart, period_chart, price_chart
from data.provider import DataUnavailableError, TwelveDataProvider
from signals.engine import DEFAULT_MIN_SCORE, DISCLAIMER, SignalResult, analyze

SECTIONS = ["Tableau de bord", "Analyse du marché", "Signaux détectés", "Graphiques",
            "Historique des analyses", "Backtesting", "Paramètres", "Documentation"]
COLORS = {"CALL": "#22C55E", "PUT": "#EF4444", "NEUTRE": "#9CA3AF"}

st.set_page_config(page_title="KLOWEN SIGNAL BOT", page_icon="📈", layout="wide")
st.markdown("""
<style>
.stApp {background: linear-gradient(160deg,#0B0B12 0%,#14142A 100%);}
h1,h2,h3 {background: linear-gradient(90deg,#8B5CF6,#3B82F6); -webkit-background-clip:text;
          -webkit-text-fill-color:transparent;}
.card {background:#14142A; border:1px solid #2A2A55; border-radius:14px; padding:18px; margin-bottom:12px;}
.sig {font-size:2.4rem; font-weight:800;}
.small {color:#9CA3AF; font-size:0.85rem;}
@media (max-width:640px){ .sig{font-size:1.8rem;} }
</style>
""", unsafe_allow_html=True)


@st.cache_resource
def get_settings():
    s = load_settings()
    configure_logging(s.log_level)
    return s


@st.cache_resource
def get_provider() -> TwelveDataProvider:
    return TwelveDataProvider(get_settings())


@st.cache_data(ttl=3600, show_spinner=False)
def cached_symbols(has_key: bool) -> list:
    return get_provider().get_supported_symbols() if has_key else list(DEFAULT_SYMBOLS)


def ss_init():
    st.session_state.setdefault("history", [])
    st.session_state.setdefault("last", None)
    st.session_state.setdefault("min_score", DEFAULT_MIN_SCORE)


def run_analysis(symbol: str, interval: str):
    provider = get_provider()
    df = provider.get_candles(symbol, interval, outputsize=300)
    result, feat = analyze(symbol, interval, df, st.session_state["min_score"])
    row = {"analyse": result.analysis_time, "symbole": result.symbol, "unité": result.interval,
           "prix": result.price, "signal": result.signal, "confiance_exp.": result.confidence,
           "volatilité": result.volatility}
    st.session_state["history"].append(row)
    return result, feat


def safe_analysis(symbol: str, interval: str):
    try:
        return run_analysis(symbol, interval)
    except DataUnavailableError as exc:
        st.warning(f"⚠️ Données indisponibles pour {symbol} : {exc}")
    except Exception:  # noqa: BLE001
        logging.getLogger(__name__).exception("Erreur inattendue pendant l'analyse")
        st.error("Erreur inattendue. Consultez les journaux techniques.")
    return None, None


def signal_card(r: SignalResult):
    color = COLORS[r.signal]
    st.markdown(f"""
<div class="card">
  <div class="small">{r.symbol} · {r.interval} · bougie clôturée {r.candle_time}</div>
  <div class="sig" style="color:{color}">{r.signal}</div>
  <div>Prix observé (fournisseur) : <b>{r.price:.5f}</b></div>
  <div>Score de confiance <i>expérimental</i> : <b>{r.confidence}/100</b>
       <span class="small">(≠ probabilité de gain)</span></div>
  <div>Volatilité : <b>{r.volatility}</b> · Analyse : {r.analysis_time}</div>
</div>""", unsafe_allow_html=True)
    for w in r.warnings:
        st.warning(w)
    st.markdown("**Raisons du signal**")
    for reason in r.reasons:
        st.write("• " + reason)
    st.caption(DISCLAIMER)


def sidebar():
    s = get_settings()
    st.sidebar.title("KLOWEN SIGNAL BOT")
    section = st.sidebar.radio("Navigation", SECTIONS)
    st.sidebar.divider()
    symbols = cached_symbols(s.has_api_key)
    default = symbols.index("EUR/USD") if "EUR/USD" in symbols else 0
    symbol = st.sidebar.selectbox("Symbole", symbols, index=default)
    interval = st.sidebar.selectbox("Unité de temps", SUPPORTED_INTERVALS, index=1)
    if not s.has_api_key:
        st.sidebar.error("Clé API absente (voir README, section Configuration).")
    return section, symbol, interval


def page_dashboard(symbol, interval):
    st.title("Tableau de bord")
    st.info(DISCLAIMER)
    if st.button("Analyser maintenant", type="primary"):
        with st.spinner("Analyse en cours…"):
            res, feat = safe_analysis(symbol, interval)
        if res:
            st.session_state["last"] = (res, feat)
    last = st.session_state["last"]
    if last:
        signal_card(last[0])
    else:
        st.write("Choisissez un symbole et une unité de temps, puis cliquez sur « Analyser maintenant ».")


def page_market():
    st.title("Analyse du marché")
    last = st.session_state["last"]
    if not last:
        st.write("Aucune analyse : lancez-en une depuis le Tableau de bord.")
        return
    res = last[0]
    st.subheader(f"{res.symbol} · {res.interval}")
    c1, c2, c3 = st.columns(3)
    c1.metric("Tendance", res.indicators["trend"])
    c2.metric("Volatilité", res.volatility)
    c3.metric("Scores (haussier / baissier)", f"{res.bull_score} / {res.bear_score}")
    table = pd.DataFrame({"indicateur": list(res.indicators), "valeur": [str(v) for v in res.indicators.values()]})
    st.dataframe(table, hide_index=True)


def page_signals(interval):
    st.title("Signaux détectés")
    st.caption("Chaque symbole analysé consomme une requête de votre quota API.")
    symbols = cached_symbols(get_settings().has_api_key)
    chosen = st.multiselect("Liste de surveillance", symbols, default=[s for s in DEFAULT_SYMBOLS[:3] if s in symbols])
    if st.button("Scanner", type="primary") and chosen:
        rows = []
        for sym in chosen:
            res, _ = safe_analysis(sym, interval)
            if res:
                rows.append({"symbole": sym, "signal": res.signal, "confiance_exp.": res.confidence,
                             "prix": res.price, "volatilité": res.volatility, "bougie": res.candle_time})
        if rows:
            df = pd.DataFrame(rows)
            st.dataframe(df, hide_index=True)
            actif = df[df["signal"] != "NEUTRE"]
            if actif.empty:
                st.write("Aucun signal CALL/PUT pour le moment.")


def page_charts():
    st.title("Graphiques")
    last = st.session_state["last"]
    if not last:
        st.write("Aucune analyse : lancez-en une depuis le Tableau de bord.")
        return
    tail = st.slider("Nombre de bougies", 50, 250, 150)
    st.plotly_chart(price_chart(last[1], tail))


def page_history():
    st.title("Historique des analyses")
    hist = st.session_state["history"]
    if not hist:
        st.write("Aucune analyse pour cette session.")
        return
    df = pd.DataFrame(hist[::-1])
    st.dataframe(df, hide_index=True)
    st.download_button("Télécharger (CSV)", df.to_csv(index=False).encode("utf-8"), "historique.csv", "text/csv")
    st.caption("L'historique est conservé pour la session en cours ; téléchargez-le pour le garder.")


def fmt_metrics(d: dict) -> dict:
    pct = lambda v: "n/a" if pd.isna(v) else f"{v:.1%}"  # noqa: E731
    return {"Signaux": d["signaux"], "Gains": d["gains"], "Pertes": d["pertes"], "Égalités": d["égalités"],
            "Taux de réussite": pct(d["taux_réussite"]),
            "IC 95 %": f"{pct(d['IC95_bas'])} – {pct(d['IC95_haut'])}",
            "Seuil de rentabilité": pct(d["seuil_rentabilité"]),
            "Espérance / trade": "n/a" if pd.isna(d["espérance_par_trade"]) else f"{d['espérance_par_trade']:+.3f}",
            "Résultat cumulé": f"{d['résultat_cumulé']:+.2f}", "Série de pertes max": d["série_pertes_max"]}


def page_backtest(symbol, interval):
    st.title("Backtesting")
    c1, c2, c3, c4 = st.columns(4)
    n = c1.slider("Bougies historiques", 500, 5000, 2000, 100)
    horizon = c2.slider("Expiration (bougies)", 1, 10, 1)
    payout = c3.slider("Payout hypothétique", 0.50, 0.95, 0.80, 0.01)
    ratio = c4.slider("Part entraînement", 0.5, 0.8, 0.7, 0.05)
    if st.button("Lancer le backtest", type="primary"):
        try:
            with st.spinner("Téléchargement et simulation…"):
                df = get_provider().get_candles(symbol, interval, outputsize=n, check_freshness=False)
                rep = run_backtest(df, BacktestConfig(horizon=horizon, payout=payout, train_ratio=ratio))
            st.session_state["bt"] = (symbol, interval, rep)
        except (DataUnavailableError, ValueError) as exc:
            st.warning(f"⚠️ Backtest impossible : {exc}")
    bt = st.session_state.get("bt")
    if not bt:
        return
    sym, itv, rep = bt
    st.subheader(f"{sym} · {itv} · seuil de score retenu sur l'entraînement : {rep.threshold}")
    st.caption(f"Séparation chronologique à {rep.split_time:%Y-%m-%d %H:%M} UTC.")
    st.dataframe(pd.DataFrame({"Entraînement": fmt_metrics(rep.train), "TEST (hors échantillon)": fmt_metrics(rep.test)}).astype(str))
    base = {"Stratégie (test)": fmt_metrics(rep.test)}
    for name, d in rep.baselines.items():
        base[f"{name} (test)"] = fmt_metrics(d["test"])
    st.markdown("**Comparaison avec des références simples (jeu de test)**")
    st.dataframe(pd.DataFrame(base).astype(str))
    test_trades = rep.trades[rep.trades["jeu"] == "test"]
    st.plotly_chart(equity_chart(test_trades))
    st.plotly_chart(period_chart(rep.by_period))
    with st.expander("Limites du backtesting et surapprentissage", expanded=True):
        for item in rep.limitations:
            st.write("• " + item)


def page_settings():
    s = get_settings()
    st.title("Paramètres")
    st.session_state["min_score"] = st.slider("Score minimal pour émettre CALL/PUT (sur 6)", 3, 6,
                                              st.session_state["min_score"])
    st.write(f"Clé API configurée : **{'oui' if s.has_api_key else 'non'}** (la valeur n'est jamais affichée)")
    st.write(f"Requêtes max / minute : {s.max_requests_per_minute} · Cache : {s.cache_ttl_seconds} s · "
             f"Bougies obsolètes au-delà de {s.max_stale_candles} intervalles")
    st.caption("Ces valeurs se modifient dans le fichier .env, puis redémarrez l'application.")


def page_docs():
    st.title("Documentation")
    st.markdown(f"""
**Méthode.** Chaque bougie clôturée reçoit un score haussier et un score baissier (max 6) : tendance EMA 9/21/50 (2 points),
MACD (1), RSI (1), Bandes de Bollinger (1), chandeliers (1). CALL/PUT exige un score ≥ seuil et un écart ≥ 2 ;
sinon NEUTRE. Les périodes de faible volatilité (ATR relatif dans le quantile bas) sont neutralisées.

**Données.** Fournisseur : Twelve Data (clé personnelle, quota limité). Les données peuvent être retardées, la bougie en
cours n'est jamais utilisée, et les données incomplètes ou obsolètes (ex. week-end) bloquent l'analyse. Aucun prix n'est inventé.
Les prix ne sont pas ceux de Pocket Option et le marché OTC n'est pas couvert.

**Pocket Option.** Aucune connexion de compte, aucun mot de passe demandé, aucune transaction automatique.
L'intégration directe reste désactivée (adaptateur indépendant prévu dans la partie suivante).

**Avertissement.** {DISCLAIMER}
""")


def main():
    ss_init()
    section, symbol, interval = sidebar()
    if section == "Tableau de bord":
        page_dashboard(symbol, interval)
    elif section == "Analyse du marché":
        page_market()
    elif section == "Signaux détectés":
        page_signals(interval)
    elif section == "Graphiques":
        page_charts()
    elif section == "Historique des analyses":
        page_history()
    elif section == "Backtesting":
        page_backtest(symbol, interval)
    elif section == "Paramètres":
        page_settings()
    else:
        page_docs()


main()

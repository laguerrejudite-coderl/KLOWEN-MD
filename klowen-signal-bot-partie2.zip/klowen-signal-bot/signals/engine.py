"""Moteur de signaux : CALL / PUT / NEUTRE.

La même fonction `score_frame` sert à l'analyse en direct ET au backtesting :
les règles testées sont donc exactement celles utilisées par l'application.
Le score de confiance est EXPÉRIMENTAL : ce n'est pas une probabilité de gain.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional

import numpy as np
import pandas as pd

from data.provider import INTERVAL_SECONDS, MIN_CANDLES, InvalidDataError
from indicators.candles import candle_patterns
from indicators.macd import macd
from indicators.moving_averages import add_emas, detect_trend
from indicators.rsi import rsi
from indicators.volatility import atr, bollinger, low_volatility, volatility_level

CALL, PUT, NEUTRE = "CALL", "PUT", "NEUTRE"
DEFAULT_MIN_SCORE = 4
MIN_EDGE = 2  # écart minimal entre scores haussier et baissier

DISCLAIMER = (
    "Signal indicatif uniquement. Il ne garantit aucun gain et ne constitue pas un conseil financier. "
    "Le score de confiance est expérimental et n'est PAS une probabilité de réussite. "
    "Les prix du fournisseur de données peuvent différer de ceux de Pocket Option (notamment en OTC)."
)

# nom : (poids, raison haussière, raison baissière)
COMPONENTS = {
    "trend": (2, "Tendance haussière : cours > EMA9 > EMA21 > EMA50, EMA21 croissante",
              "Tendance baissière : cours < EMA9 < EMA21 < EMA50, EMA21 décroissante"),
    "macd": (1, "Histogramme MACD positif et croissant", "Histogramme MACD négatif et décroissant"),
    "rsi": (1, "RSI en zone haussière (entre 50 et 70)", "RSI en zone baissière (entre 30 et 50)"),
    "bollinger": (1, "Cours au-dessus de la bande médiane, sous la bande haute",
                  "Cours sous la bande médiane, au-dessus de la bande basse"),
    "candle": (1, "Chandelier haussier (avalement haussier ou marteau)",
               "Chandelier baissier (avalement baissier ou étoile filante)"),
}
MAX_SCORE = sum(w for w, _, _ in COMPONENTS.values())
READY_COLS = ["ema_50", "rsi", "macd_signal", "bb_mid", "bb_upper", "bb_lower", "atr"]


def compute_features(df: pd.DataFrame) -> pd.DataFrame:
    """Calcule tous les indicateurs (uniquement causaux : aucune information du futur)."""
    close = df["close"]
    emas = add_emas(close)
    feat = df[["open", "high", "low", "close"]].copy().join(emas)
    feat["trend"] = detect_trend(emas, close)
    feat["rsi"] = rsi(close)
    feat = feat.join(macd(close)).join(bollinger(close))
    feat["atr"] = atr(df["high"], df["low"], close)
    feat["low_vol"] = low_volatility(feat["atr"], close)
    return feat.join(candle_patterns(df))


def score_frame(feat: pd.DataFrame, min_score: int = DEFAULT_MIN_SCORE) -> pd.DataFrame:
    close, hist = feat["close"], feat["macd_hist"]
    ready = feat[READY_COLS].notna().all(axis=1) & (feat["trend"] != "unknown")
    bull = {
        "trend": feat["trend"] == "up",
        "macd": (hist > 0) & (hist > hist.shift(1)),
        "rsi": (feat["rsi"] > 50) & (feat["rsi"] < 70),
        "bollinger": (close > feat["bb_mid"]) & (close <= feat["bb_upper"]),
        "candle": feat["bullish_engulfing"] | feat["hammer"],
    }
    bear = {
        "trend": feat["trend"] == "down",
        "macd": (hist < 0) & (hist < hist.shift(1)),
        "rsi": (feat["rsi"] < 50) & (feat["rsi"] > 30),
        "bollinger": (close < feat["bb_mid"]) & (close >= feat["bb_lower"]),
        "candle": feat["bearish_engulfing"] | feat["shooting_star"],
    }
    out = pd.DataFrame(index=feat.index)
    bull_score = pd.Series(0, index=feat.index)
    bear_score = pd.Series(0, index=feat.index)
    for name, (weight, _, _) in COMPONENTS.items():
        out[f"bull_{name}"] = (bull[name] & ready).astype(bool)
        out[f"bear_{name}"] = (bear[name] & ready).astype(bool)
        bull_score = bull_score + out[f"bull_{name}"].astype(int) * weight
        bear_score = bear_score + out[f"bear_{name}"].astype(int) * weight

    tradable = ready & ~feat["low_vol"].astype(bool)
    call = tradable & (bull_score >= min_score) & (bull_score - bear_score >= MIN_EDGE)
    put = tradable & (bear_score >= min_score) & (bear_score - bull_score >= MIN_EDGE)
    out["bull_score"], out["bear_score"] = bull_score, bear_score
    out["ready"], out["tradable"] = ready, tradable
    out["signal"] = pd.Series(np.where(call, CALL, np.where(put, PUT, NEUTRE)), index=feat.index)
    gap = (bull_score - bear_score).abs()
    out["confidence"] = np.where(out["signal"] == NEUTRE, 0, (gap / MAX_SCORE * 100).round())
    return out


@dataclass
class SignalResult:
    symbol: str
    interval: str
    analysis_time: str
    candle_time: str
    price: float
    signal: str
    confidence: int
    bull_score: int
    bear_score: int
    volatility: str
    reasons: list = field(default_factory=list)
    indicators: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    disclaimer: str = DISCLAIMER

    def to_dict(self) -> dict:
        return asdict(self)


def drop_unclosed(df: pd.DataFrame, interval: str, now: Optional[pd.Timestamp] = None) -> pd.DataFrame:
    """Retire la bougie en cours de formation : on n'analyse que des bougies clôturées."""
    now = now or pd.Timestamp.now(tz="UTC")
    end = df.index + pd.Timedelta(seconds=INTERVAL_SECONDS[interval])
    return df[end <= now]


def analyze(symbol: str, interval: str, df: pd.DataFrame, min_score: int = DEFAULT_MIN_SCORE,
            now: Optional[pd.Timestamp] = None) -> tuple[SignalResult, pd.DataFrame]:
    now = now or pd.Timestamp.now(tz="UTC")
    closed = drop_unclosed(df, interval, now)
    if len(closed) < MIN_CANDLES:
        raise InvalidDataError(f"Pas assez de bougies clôturées ({len(closed)}).")
    feat = compute_features(closed)
    scored = score_frame(feat, min_score)
    row, sc = feat.iloc[-1], scored.iloc[-1]
    signal = str(sc["signal"])
    vol = volatility_level(feat["atr"], feat["close"])

    warnings = []
    if not sc["ready"]:
        warnings.append("Indicateurs incomplets : aucun signal produit.")
    elif bool(row["low_vol"]):
        warnings.append("Période de faible volatilité : signal neutralisé.")
    if signal == NEUTRE and sc["bull_score"] >= 2 and sc["bear_score"] >= 2:
        warnings.append("Indicateurs contradictoires.")

    side = "bull" if signal == CALL else "bear" if signal == PUT else None
    reasons = []
    if side:
        idx = 1 if side == "bull" else 2
        reasons = [COMPONENTS[n][idx] for n in COMPONENTS if sc[f"{side}_{n}"]]
    else:
        reasons = [f"Conditions insuffisantes ou contradictoires (score haussier {int(sc['bull_score'])}, "
                   f"baissier {int(sc['bear_score'])}, seuil {min_score}, écart minimal {MIN_EDGE})."]

    keys = ["rsi", "macd", "macd_signal", "macd_hist", "ema_9", "ema_21", "ema_50",
            "bb_upper", "bb_mid", "bb_lower", "atr"]
    indicators = {k: (None if pd.isna(row[k]) else round(float(row[k]), 6)) for k in keys}
    indicators["trend"] = str(row["trend"])
    indicators["low_volatility"] = bool(row["low_vol"])

    result = SignalResult(
        symbol=symbol, interval=interval,
        analysis_time=now.strftime("%Y-%m-%d %H:%M:%S UTC"),
        candle_time=feat.index[-1].strftime("%Y-%m-%d %H:%M UTC"),
        price=float(row["close"]), signal=signal, confidence=int(sc["confidence"]),
        bull_score=int(sc["bull_score"]), bear_score=int(sc["bear_score"]),
        volatility=vol, reasons=reasons, indicators=indicators, warnings=warnings,
    )
    return result, feat.join(scored[["signal"]])

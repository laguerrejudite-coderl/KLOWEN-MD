"""Fournisseur de données : Twelve Data (API officielle, clé gratuite disponible).

Aucune donnée n'est jamais fabriquée : en cas de problème, une exception explicite
est levée et l'interface affiche un avertissement.
Les prix obtenus ici ne sont PAS ceux de Pocket Option (ni le marché OTC).
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from typing import Optional

import pandas as pd
import requests

from config.settings import DEFAULT_SYMBOLS, SUPPORTED_INTERVALS, Settings
from data.cache import TTLCache

logger = logging.getLogger(__name__)

INTERVAL_SECONDS = {
    "1min": 60, "5min": 300, "15min": 900, "30min": 1800,
    "1h": 3600, "4h": 14400, "1day": 86400,
}
OHLC = ["open", "high", "low", "close"]
MIN_CANDLES = 60  # nécessaire pour EMA 50 + marge


class DataUnavailableError(RuntimeError):
    """Données indisponibles (réseau, clé, quota, symbole)."""


class InvalidDataError(DataUnavailableError):
    """Données reçues invalides ou insuffisantes."""


class StaleDataError(DataUnavailableError):
    """Dernière bougie trop ancienne (marché fermé ou flux en retard)."""


class RateLimiter:
    """Limite le nombre de requêtes par minute (fenêtre glissante)."""

    def __init__(self, max_per_minute: int) -> None:
        self.max_per_minute = max_per_minute
        self._calls: deque[float] = deque()
        self._lock = threading.Lock()

    def acquire(self, max_wait: float = 15.0) -> None:
        deadline = time.monotonic() + max_wait
        while True:
            with self._lock:
                now = time.monotonic()
                while self._calls and now - self._calls[0] >= 60:
                    self._calls.popleft()
                if len(self._calls) < self.max_per_minute:
                    self._calls.append(now)
                    return
                wait = 60 - (now - self._calls[0])
            if time.monotonic() + wait > deadline:
                raise DataUnavailableError("Limite de requêtes atteinte, réessayez dans quelques instants.")
            time.sleep(min(wait, 1.0))


def validate_candles(
    df: pd.DataFrame,
    interval: str,
    max_stale_candles: int = 3,
    check_freshness: bool = True,
    now: Optional[pd.Timestamp] = None,
) -> pd.DataFrame:
    """Nettoie et valide un DataFrame OHLC indexé par date UTC. Lève une exception si inutilisable."""
    if interval not in INTERVAL_SECONDS:
        raise InvalidDataError(f"Unité de temps non prise en charge : {interval}")
    missing = [c for c in OHLC if c not in df.columns]
    if missing:
        raise InvalidDataError(f"Colonnes manquantes : {missing}")

    out = df.copy()
    for col in OHLC + (["volume"] if "volume" in out.columns else []):
        out[col] = pd.to_numeric(out[col], errors="coerce")
    out = out[~out.index.duplicated(keep="last")].sort_index()

    before = len(out)
    out = out.dropna(subset=OHLC)
    out = out[(out[OHLC] > 0).all(axis=1)]
    coherent = (
        (out["high"] >= out[["open", "close", "low"]].max(axis=1))
        & (out["low"] <= out[["open", "close", "high"]].min(axis=1))
    )
    out = out[coherent]
    dropped = before - len(out)
    if dropped:
        logger.warning("%d bougies invalides ignorées.", dropped)

    if len(out) < MIN_CANDLES:
        raise InvalidDataError(f"Données insuffisantes ({len(out)} bougies valides, {MIN_CANDLES} requises).")
    if dropped / max(before, 1) > 0.2:
        raise InvalidDataError("Trop de bougies invalides : données non fiables.")

    if check_freshness:
        now = now or pd.Timestamp.now(tz="UTC")
        age = (now - out.index[-1]).total_seconds()
        limit = INTERVAL_SECONDS[interval] * (max_stale_candles + 1)
        if age > limit:
            raise StaleDataError(
                f"Dernière bougie datée de {out.index[-1]:%Y-%m-%d %H:%M} UTC : données obsolètes "
                "(le marché est peut-être fermé, ex. week-end)."
            )
    return out


class TwelveDataProvider:
    def __init__(self, settings: Settings, session: Optional[requests.Session] = None) -> None:
        self.settings = settings
        self.session = session or requests.Session()
        self.cache = TTLCache(settings.cache_ttl_seconds)
        self.limiter = RateLimiter(settings.max_requests_per_minute)

    def _get(self, endpoint: str, params: dict) -> dict:
        if not self.settings.has_api_key:
            raise DataUnavailableError("Clé API absente : renseignez TWELVEDATA_API_KEY dans le fichier .env.")
        self.limiter.acquire()
        full = {**params, "apikey": self.settings.twelvedata_api_key}
        logger.info("Requête %s %s", endpoint, params)  # la clé n'est jamais journalisée
        try:
            resp = self.session.get(
                f"{self.settings.base_url}/{endpoint}", params=full,
                timeout=self.settings.request_timeout_seconds,
            )
            resp.raise_for_status()
            payload = resp.json()
        except requests.Timeout as exc:
            raise DataUnavailableError("Délai dépassé lors de l'appel au fournisseur.") from exc
        except requests.RequestException as exc:
            raise DataUnavailableError(f"Erreur réseau : {type(exc).__name__}") from exc
        except ValueError as exc:
            raise InvalidDataError("Réponse du fournisseur illisible.") from exc
        if not isinstance(payload, dict):
            raise InvalidDataError("Format de réponse inattendu.")
        if payload.get("status") == "error":
            code = payload.get("code")
            msg = str(payload.get("message", "erreur inconnue"))[:200]
            raise DataUnavailableError(f"Fournisseur (code {code}) : {msg}")
        return payload

    def get_supported_symbols(self) -> list[str]:
        """Paires forex proposées par le fournisseur ; liste par défaut en cas d'échec."""
        cached = self.cache.get("symbols")
        if cached:
            return cached
        try:
            data = self._get("forex_pairs", {}).get("data", [])
            symbols = sorted({d["symbol"] for d in data if isinstance(d, dict) and "symbol" in d})
            if symbols:
                self.cache.set("symbols", symbols)
                return symbols
        except DataUnavailableError as exc:
            logger.warning("Liste des symboles indisponible : %s", exc)
        return list(DEFAULT_SYMBOLS)

    def get_candles(self, symbol: str, interval: str, outputsize: int = 300,
                    check_freshness: bool = True) -> pd.DataFrame:
        if interval not in SUPPORTED_INTERVALS:
            raise InvalidDataError(f"Unité de temps non prise en charge : {interval}")
        outputsize = max(MIN_CANDLES, min(int(outputsize), 5000))
        key = f"{symbol}|{interval}|{outputsize}"
        raw = self.cache.get(key)
        if raw is None:
            payload = self._get("time_series", {
                "symbol": symbol, "interval": interval,
                "outputsize": outputsize, "timezone": "UTC", "order": "ASC",
            })
            values = payload.get("values")
            if not values:
                raise InvalidDataError(f"Aucune donnée reçue pour {symbol}.")
            raw = pd.DataFrame(values)
            self.cache.set(key, raw)
        df = raw.copy()
        if "datetime" not in df.columns:
            raise InvalidDataError("Colonne 'datetime' absente.")
        df["datetime"] = pd.to_datetime(df["datetime"], utc=True, errors="coerce")
        df = df.dropna(subset=["datetime"]).set_index("datetime")
        return validate_candles(df, interval, self.settings.max_stale_candles, check_freshness)

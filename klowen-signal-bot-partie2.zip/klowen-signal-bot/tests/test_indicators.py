import numpy as np
import pandas as pd
import pytest

from data.provider import InvalidDataError, StaleDataError, validate_candles
from indicators.candles import candle_patterns
from indicators.macd import macd
from indicators.moving_averages import add_emas, detect_trend
from indicators.rsi import rsi
from indicators.volatility import atr, bollinger, low_volatility


def make_df(n=200, drift=0.0005, seed=1, start="2024-01-01"):
    rng = np.random.default_rng(seed)
    close = 1.1 * np.exp(np.cumsum(drift * 0.1 + rng.normal(0, 0.0005, n)))
    open_ = np.r_[close[0], close[:-1]]
    high = np.maximum(open_, close) * (1 + 0.0002)
    low = np.minimum(open_, close) * (1 - 0.0002)
    idx = pd.date_range(start, periods=n, freq="5min", tz="UTC")
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close}, index=idx)


def test_rsi_bounds_and_extremes():
    up = pd.Series(np.arange(1, 100, dtype=float))
    assert rsi(up).dropna().iloc[-1] == 100
    assert rsi(-up + 200).dropna().iloc[-1] < 1
    r = rsi(make_df()["close"]).dropna()
    assert r.between(0, 100).all()


def test_rsi_warmup_is_nan():
    assert rsi(make_df()["close"], 14).iloc[:14].isna().all()


def test_macd_columns_and_hist():
    m = macd(make_df()["close"]).dropna()
    assert np.allclose(m["macd_hist"], m["macd"] - m["macd_signal"])


def test_macd_invalid_params():
    with pytest.raises(ValueError):
        macd(make_df()["close"], fast=26, slow=12)


def test_ema_and_uptrend():
    close = pd.Series(np.linspace(1.0, 1.5, 200), index=make_df().index)
    e = add_emas(close)
    assert detect_trend(e, close).iloc[-1] == "up"
    assert detect_trend(add_emas(close[::-1].set_axis(close.index)), close[::-1].set_axis(close.index)).iloc[-1] == "down"


def test_bollinger_order():
    b = bollinger(make_df()["close"]).dropna()
    assert (b["bb_upper"] >= b["bb_mid"]).all() and (b["bb_mid"] >= b["bb_lower"]).all()


def test_atr_positive_and_low_vol_no_lookahead():
    df = make_df()
    a = atr(df["high"], df["low"], df["close"]).dropna()
    assert (a > 0).all()
    full = low_volatility(atr(df["high"], df["low"], df["close"]), df["close"])
    cut = low_volatility(atr(df["high"][:150], df["low"][:150], df["close"][:150]), df["close"][:150])
    assert (full[:150] == cut).all()


def test_candle_patterns_engulfing():
    idx = pd.date_range("2024-01-01", periods=2, freq="5min", tz="UTC")
    df = pd.DataFrame({"open": [1.10, 1.085], "high": [1.101, 1.112], "low": [1.089, 1.084],
                       "close": [1.09, 1.11]}, index=idx)
    assert candle_patterns(df)["bullish_engulfing"].iloc[1]


def test_validate_rejects_stale_and_short_data():
    df = make_df()
    with pytest.raises(StaleDataError):
        validate_candles(df, "5min", now=pd.Timestamp("2030-01-01", tz="UTC"))
    with pytest.raises(InvalidDataError):
        validate_candles(df.iloc[:10], "5min", check_freshness=False)


def test_validate_drops_bad_rows():
    df = make_df()
    df.iloc[5, df.columns.get_loc("close")] = np.nan
    out = validate_candles(df, "5min", check_freshness=False)
    assert len(out) == len(df) - 1

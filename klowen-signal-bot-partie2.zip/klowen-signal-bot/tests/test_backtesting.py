import pandas as pd

from backtesting.engine import BacktestConfig, run_backtest, simulate, wilson_interval
from tests.test_indicators import make_df


def tiny():
    idx = pd.date_range("2024-01-01", periods=6, freq="5min", tz="UTC")
    return pd.DataFrame({"open": [1, 1, 2, 2, 3, 3.0], "high": [4] * 6, "low": [0.5] * 6,
                         "close": [1, 2, 2, 3, 3, 4.0]}, index=idx)


def test_entry_at_next_open_and_pnl():
    df = tiny()
    sig = pd.Series(["CALL", "NEUTRE", "NEUTRE", "NEUTRE", "NEUTRE", "NEUTRE"], index=df.index)
    t = simulate(df, sig, horizon=1, payout=0.8, start=0, end=6)
    assert len(t) == 1 and t.iloc[0]["entry"] == df["open"].iloc[1]
    assert t.iloc[0]["exit"] == df["close"].iloc[1] and t.iloc[0]["pnl"] == 0.8


def test_put_loses_on_rise_and_no_overlap():
    df = tiny()
    sig = pd.Series(["PUT"] * 6, index=df.index)
    t = simulate(df, sig, horizon=2, payout=0.8, start=0, end=6)
    assert (t["pnl"] == -1.0).all()
    assert (t["entry_time"].iloc[1:].to_numpy() >= t["exit_time"].iloc[:-1].to_numpy()).all()


def test_tie_is_push():
    df = tiny()
    sig = pd.Series(["CALL", "NEUTRE", "NEUTRE", "NEUTRE", "NEUTRE", "NEUTRE"], index=df.index)
    df.loc[df.index[1], "close"] = df["open"].iloc[1]
    t = simulate(df, sig, 1, 0.8, 0, 6)
    assert t.iloc[0]["result"] == "push" and t.iloc[0]["pnl"] == 0.0


def test_wilson_interval_bounds():
    lo, hi = wilson_interval(60, 100)
    assert 0.49 < lo < 0.6 < hi < 0.70
    assert wilson_interval(0, 0)[0] != wilson_interval(0, 0)[0]  # NaN


def test_run_backtest_split_is_chronological():
    df = make_df(1200, drift=0.02)
    rep = run_backtest(df, BacktestConfig())
    train = rep.trades[rep.trades["jeu"] == "entraînement"]
    test = rep.trades[rep.trades["jeu"] == "test"]
    if len(train) and len(test):
        assert train["exit_time"].max() < rep.split_time <= test["signal_time"].min() or \
               train["exit_time"].max() <= rep.split_time
    assert set(rep.baselines) == {"Toujours CALL", "Direction de la bougie précédente"}
    assert rep.limitations


def test_run_backtest_needs_enough_data():
    import pytest
    with pytest.raises(ValueError):
        run_backtest(make_df(100))

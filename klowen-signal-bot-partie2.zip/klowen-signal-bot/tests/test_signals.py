import numpy as np
import pandas as pd

from signals.engine import CALL, NEUTRE, PUT, analyze, compute_features, drop_unclosed, score_frame
from tests.test_indicators import make_df

BOOLS = ["bullish_engulfing", "bearish_engulfing", "hammer", "shooting_star", "low_vol"]


def crafted(**over):
    base = dict(open=1.0, high=1.01, low=0.99, close=1.005, ema_50=1.0, rsi=60.0, macd=0.1, macd_signal=0.05,
                macd_hist=0.05, bb_mid=1.0, bb_upper=1.02, bb_lower=0.98, atr=0.001, trend="up",
                bullish_engulfing=True, bearish_engulfing=False, hammer=False, shooting_star=False, low_vol=False)
    base.update(over)
    idx = pd.date_range("2024-01-01", periods=2, freq="5min", tz="UTC")
    df = pd.DataFrame([{**base, "macd_hist": 0.01}, base], index=idx)
    for c in BOOLS:
        df[c] = df[c].astype(bool)
    return df


def test_call_when_all_bullish():
    assert score_frame(crafted()).iloc[-1]["signal"] == CALL


def test_put_when_all_bearish():
    f = crafted(trend="down", rsi=40.0, macd_hist=-0.05, close=0.995, bullish_engulfing=False, bearish_engulfing=True)
    f.loc[f.index[0], "macd_hist"] = -0.01
    assert score_frame(f).iloc[-1]["signal"] == PUT


def test_neutral_when_low_volatility():
    assert score_frame(crafted(low_vol=True)).iloc[-1]["signal"] == NEUTRE


def test_neutral_when_incomplete():
    assert score_frame(crafted(ema_50=np.nan)).iloc[-1]["signal"] == NEUTRE


def test_neutral_when_conflicting():
    f = crafted(trend="flat", bullish_engulfing=False, macd_hist=-0.05)
    assert score_frame(f).iloc[-1]["signal"] == NEUTRE


def test_no_lookahead_in_signals():
    df = make_df(400)
    full = score_frame(compute_features(df))["signal"]
    cut = score_frame(compute_features(df.iloc[:300]))["signal"]
    assert (full.iloc[:300].to_numpy() == cut.to_numpy()).all()


def test_drop_unclosed_removes_forming_candle():
    df = make_df(100)
    now = df.index[-1] + pd.Timedelta(minutes=2)  # dernière bougie 5 min encore en formation
    assert len(drop_unclosed(df, "5min", now)) == 99


def test_analyze_returns_complete_result():
    df = make_df(300)
    now = df.index[-1] + pd.Timedelta(minutes=10)
    res, feat = analyze("EUR/USD", "5min", df, now=now)
    assert res.signal in (CALL, PUT, NEUTRE)
    assert res.symbol == "EUR/USD" and res.reasons and "rsi" in res.indicators
    assert 0 <= res.confidence <= 100 and "garantit" in res.disclaimer or "gain" in res.disclaimer

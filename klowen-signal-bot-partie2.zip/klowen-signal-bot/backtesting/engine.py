"""Backtesting sans biais d'anticipation.

Hypothèses (modifiables, toutes affichées dans l'application) :
- Le signal est calculé à la CLÔTURE de la bougie t avec les seules données jusqu'à t.
- L'entrée se fait à l'OUVERTURE de la bougie t+1 ; la sortie à la clôture de la bougie t+horizon.
- Gain = +payout (ex. 0,80 de la mise), perte = -1, égalité = 0. Le payout joue le rôle de coût de transaction.
- Un seul trade à la fois (pas de chevauchement).
- Découpage chronologique entraînement / test ; le seuil de score est choisi sur l'entraînement UNIQUEMENT.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from signals.engine import CALL, DEFAULT_MIN_SCORE, NEUTRE, PUT, compute_features, score_frame

LIMITATIONS = [
    "Les performances passées ne prédisent pas les résultats futurs.",
    "Un taux de réussite élevé sur peu de trades est statistiquement peu fiable : consultez l'intervalle de confiance.",
    "Surapprentissage : plus on ajuste de paramètres sur le passé, plus les résultats semblent bons à tort. "
    "Seule la période de TEST (jamais utilisée pour choisir le seuil) est informative.",
    "Les prix du fournisseur diffèrent de ceux de Pocket Option ; le payout réel varie selon l'actif et l'heure.",
    "Aucun glissement (slippage), délai d'exécution ni marché OTC n'est modélisé.",
]


@dataclass
class BacktestConfig:
    horizon: int = 1
    payout: float = 0.80
    train_ratio: float = 0.70
    thresholds: tuple = (3, 4, 5)
    min_trades_for_selection: int = 20
    period: str = "W"


@dataclass
class BacktestReport:
    config: BacktestConfig
    threshold: int
    split_time: pd.Timestamp
    train: dict
    test: dict
    baselines: dict
    trades: pd.DataFrame
    by_period: pd.DataFrame
    limitations: list


def wilson_interval(wins: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (float("nan"), float("nan"))
    p = wins / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def simulate(df: pd.DataFrame, signals: pd.Series, horizon: int, payout: float,
             start: int, end: int) -> pd.DataFrame:
    """Simule les trades sur les indices [start, end). Entrée = open[i+1], sortie = close[i+horizon]."""
    if horizon < 1:
        raise ValueError("horizon doit être >= 1")
    o, c = df["open"].to_numpy(), df["close"].to_numpy()
    sig, idx = signals.to_numpy(), df.index
    rows, i = [], start
    while i + horizon < end:
        s = sig[i]
        if s == CALL or s == PUT:
            entry, exit_ = o[i + 1], c[i + horizon]
            if exit_ == entry:
                result, pnl = "push", 0.0
            elif (s == CALL) == (exit_ > entry):
                result, pnl = "win", payout
            else:
                result, pnl = "loss", -1.0
            rows.append({"signal_time": idx[i], "entry_time": idx[i + 1], "exit_time": idx[i + horizon],
                         "direction": s, "entry": entry, "exit": exit_, "result": result, "pnl": pnl})
            i += horizon
        else:
            i += 1
    cols = ["signal_time", "entry_time", "exit_time", "direction", "entry", "exit", "result", "pnl"]
    return pd.DataFrame(rows, columns=cols)


def summarize(trades: pd.DataFrame, payout: float) -> dict:
    n = len(trades)
    wins = int((trades["result"] == "win").sum())
    losses = int((trades["result"] == "loss").sum())
    pushes = n - wins - losses
    decided = wins + losses
    streak = best = 0
    for r in trades["result"]:
        streak = streak + 1 if r == "loss" else 0
        best = max(best, streak)
    lo, hi = wilson_interval(wins, decided)
    return {
        "signaux": n, "gains": wins, "pertes": losses, "égalités": pushes,
        "taux_réussite": wins / decided if decided else float("nan"),
        "IC95_bas": lo, "IC95_haut": hi,
        "seuil_rentabilité": 1 / (1 + payout),
        "espérance_par_trade": float(trades["pnl"].mean()) if n else float("nan"),
        "résultat_cumulé": float(trades["pnl"].sum()),
        "série_pertes_max": best,
    }


def _by_period(trades: pd.DataFrame, period: str) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame(columns=["période", "signaux", "taux_réussite", "résultat"])
    p = trades["entry_time"].dt.tz_localize(None).dt.to_period(period).astype(str)
    g = trades.assign(période=p).groupby("période")
    return pd.DataFrame({
        "signaux": g.size(),
        "taux_réussite": g.apply(lambda x: (x["result"] == "win").sum()
                                 / max(1, (x["result"] != "push").sum())),
        "résultat": g["pnl"].sum(),
    }).reset_index()


def run_backtest(df: pd.DataFrame, config: Optional[BacktestConfig] = None) -> BacktestReport:
    config = config or BacktestConfig()
    if len(df) < 300:
        raise ValueError("Au moins 300 bougies sont nécessaires pour un backtest.")
    n = len(df)
    split = int(n * config.train_ratio)
    feat = compute_features(df)  # indicateurs causaux : pas d'anticipation

    best_thr, best_exp = DEFAULT_MIN_SCORE, -np.inf
    for thr in config.thresholds:  # choix du seuil sur l'ENTRAÎNEMENT uniquement
        sig = score_frame(feat, thr)["signal"]
        t = simulate(df, sig, config.horizon, config.payout, 0, split)
        if len(t) >= config.min_trades_for_selection and t["pnl"].mean() > best_exp:
            best_thr, best_exp = thr, float(t["pnl"].mean())

    signals = score_frame(feat, best_thr)["signal"]
    train_t = simulate(df, signals, config.horizon, config.payout, 0, split)
    test_t = simulate(df, signals, config.horizon, config.payout, split, n)

    base_signals = {
        "Toujours CALL": pd.Series(CALL, index=df.index),
        "Direction de la bougie précédente": pd.Series(
            np.where(df["close"] > df["open"], CALL, np.where(df["close"] < df["open"], PUT, NEUTRE)),
            index=df.index),
    }
    baselines = {}
    for name, s in base_signals.items():
        baselines[name] = {
            "train": summarize(simulate(df, s, config.horizon, config.payout, 0, split), config.payout),
            "test": summarize(simulate(df, s, config.horizon, config.payout, split, n), config.payout),
        }

    trades = pd.concat([train_t.assign(jeu="entraînement"), test_t.assign(jeu="test")], ignore_index=True)
    return BacktestReport(
        config=config, threshold=best_thr, split_time=df.index[split],
        train=summarize(train_t, config.payout), test=summarize(test_t, config.payout),
        baselines=baselines, trades=trades, by_period=_by_period(test_t, config.period),
        limitations=LIMITATIONS,
    )

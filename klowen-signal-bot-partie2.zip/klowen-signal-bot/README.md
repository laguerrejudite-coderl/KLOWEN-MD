# KLOWEN SIGNAL BOT

Application d'analyse technique qui produit des **signaux indicatifs** CALL / PUT / NEUTRE, avec tableau de bord Streamlit et backtesting.

> ⚠️ **Avertissement.** Aucun signal ne garantit un gain. Le « score de confiance » est expérimental et n'est **pas** une probabilité de réussite. Les options binaires et le trading comportent un risque élevé de perte en capital. Les prix du fournisseur de données ne sont pas ceux de Pocket Option (ni du marché OTC). Aucun ordre n'est jamais passé automatiquement.

## Fonctionnalités
RSI, MACD, EMA 9/21/50, Bollinger, ATR, détection de tendance, chandeliers, détection de faible volatilité, validation des données (jamais de prix inventés), backtesting sans biais d'anticipation (entraînement / test, références simples, intervalle de confiance).

## Installation (Windows + Visual Studio Code)
1. Installez **Python 3.10+** depuis python.org (cochez « Add Python to PATH ») et **VS Code** avec l'extension *Python*.
2. Dézippez le projet, puis `Fichier > Ouvrir le dossier` dans VS Code.
3. Ouvrez un terminal (`Ctrl+ù` ou `Terminal > Nouveau terminal`, type PowerShell) :

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```
Si PowerShell bloque l'activation : `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`, puis relancez.
Dans VS Code : `Ctrl+Maj+P` > *Python: Select Interpreter* > choisissez `.venv`.

## Configuration du fournisseur de données (Twelve Data)
1. Créez un compte gratuit sur twelvedata.com et copiez votre clé API.
2. Ouvrez `.env` et remplacez `votre_cle_api_ici` par votre clé. **Ne partagez jamais ce fichier** (il doit rester hors de Git).
3. Le plan gratuit est limité (quota par minute et par jour, couverture variable selon les symboles et unités) : vérifiez les limites actuelles sur leur page de tarifs et adaptez `MAX_REQUESTS_PER_MINUTE`.

## Démarrage
```powershell
streamlit run app.py
```
Ouvrez ensuite http://localhost:8501. Sur téléphone (même Wi-Fi) : `http://<IP-du-PC>:8501`.

## Tests
```powershell
pytest -q
```

## Erreurs fréquentes
| Message | Cause / solution |
|---|---|
| « Clé API absente » | `.env` manquant ou clé non renseignée ; redémarrez Streamlit après modification. |
| « Fournisseur (code 401…) » | Clé invalide : recopiez-la. |
| « Fournisseur (code 429…) » / « Limite de requêtes atteinte » | Quota dépassé : attendez, réduisez les scans, baissez `MAX_REQUESTS_PER_MINUTE`. |
| « Données obsolètes » | Marché fermé (week-end) ou flux retardé : normal, aucun signal n'est produit. |
| « Données insuffisantes » | Symbole ou unité peu fournis : essayez une autre unité de temps. |
| `ModuleNotFoundError` | Environnement virtuel non activé ou `pip install -r requirements.txt` oublié. |
| `streamlit` introuvable | Utilisez `python -m streamlit run app.py`. |

## Déploiement gratuit (Streamlit Community Cloud)
1. Poussez le projet sur GitHub (**sans** `.env` : ajoutez-le à `.gitignore`).
2. Sur share.streamlit.io : *New app*, choisissez le dépôt, fichier `app.py`.
3. Dans *Advanced settings > Secrets*, ajoutez : `TWELVEDATA_API_KEY = "votre_cle"`.

Limites (à vérifier sur la documentation actuelle de Streamlit) : ressources modestes, application mise en veille après inactivité, disque non persistant (l'historique n'est conservé que pendant la session), et le quota gratuit de Twelve Data est **partagé entre tous les visiteurs** de votre application : protégez l'accès si vous la rendez publique.

## Pocket Option
Aucune connexion de compte n'est implémentée. L'application analyse des données externes sans accès à votre compte. Aucun mot de passe n'est demandé et aucune transaction automatique n'existe.

## Structure
`app.py` (interface) · `config/` (réglages) · `data/` (fournisseur, cache) · `indicators/` (RSI, MACD, EMA, volatilité, chandeliers) · `signals/engine.py` (règles) · `backtesting/engine.py` · `dashboard/charts.py` · `tests/`

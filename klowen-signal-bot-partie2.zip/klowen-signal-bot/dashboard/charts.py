"""Graphiques Plotly (thème sombre noir / violet / bleu)."""
from __future__ import annotations

from typing import Optional

import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

BG, PANEL = "#0B0B12", "#14142A"
VIOLET, BLUE, GREEN, RED, GREY = "#8B5CF6", "#3B82F6", "#22C55E", "#EF4444", "#9CA3AF"


def _style(fig: go.Figure, height: int) -> go.Figure:
    fig.update_layout(
        template="plotly_dark", paper_bgcolor=BG, plot_bgcolor=BG, height=height,
        margin=dict(l=10, r=10, t=30, b=10),
        legend=dict(orientation="h", y=1.02, x=0),
        xaxis_rangeslider_visible=False,
    )
    fig.update_xaxes(gridcolor="#1F1F3A")
    fig.update_yaxes(gridcolor="#1F1F3A")
    return fig


def price_chart(feat: pd.DataFrame, tail: int = 150, show_signals: bool = True) -> go.Figure:
    d = feat.tail(tail)
    fig = make_subplots(rows=3, cols=1, shared_xaxes=True, row_heights=[0.6, 0.2, 0.2], vertical_spacing=0.03)
    fig.add_trace(go.Candlestick(x=d.index, open=d["open"], high=d["high"], low=d["low"], close=d["close"],
                                 name="Prix", increasing_line_color=GREEN, decreasing_line_color=RED), 1, 1)
    for col, color in (("ema_9", "#F59E0B"), ("ema_21", BLUE), ("ema_50", VIOLET)):
        fig.add_trace(go.Scatter(x=d.index, y=d[col], name=col.upper().replace("_", " "),
                                 line=dict(color=color, width=1.3)), 1, 1)
    fig.add_trace(go.Scatter(x=d.index, y=d["bb_upper"], name="Bollinger haute",
                             line=dict(color=GREY, width=1, dash="dot")), 1, 1)
    fig.add_trace(go.Scatter(x=d.index, y=d["bb_lower"], name="Bollinger basse",
                             line=dict(color=GREY, width=1, dash="dot")), 1, 1)
    if show_signals and "signal" in d.columns:
        calls, puts = d[d["signal"] == "CALL"], d[d["signal"] == "PUT"]
        fig.add_trace(go.Scatter(x=calls.index, y=calls["low"] * 0.9998, mode="markers", name="CALL",
                                 marker=dict(symbol="triangle-up", size=11, color=GREEN)), 1, 1)
        fig.add_trace(go.Scatter(x=puts.index, y=puts["high"] * 1.0002, mode="markers", name="PUT",
                                 marker=dict(symbol="triangle-down", size=11, color=RED)), 1, 1)
    fig.add_trace(go.Scatter(x=d.index, y=d["rsi"], name="RSI", line=dict(color=VIOLET)), 2, 1)
    fig.add_hline(y=70, line_dash="dash", line_color=RED, row=2, col=1)
    fig.add_hline(y=30, line_dash="dash", line_color=GREEN, row=2, col=1)
    colors = [GREEN if v >= 0 else RED for v in d["macd_hist"].fillna(0)]
    fig.add_trace(go.Bar(x=d.index, y=d["macd_hist"], name="Histogramme", marker_color=colors), 3, 1)
    fig.add_trace(go.Scatter(x=d.index, y=d["macd"], name="MACD", line=dict(color=BLUE)), 3, 1)
    fig.add_trace(go.Scatter(x=d.index, y=d["macd_signal"], name="Signal", line=dict(color="#F59E0B")), 3, 1)
    fig.update_yaxes(range=[0, 100], row=2, col=1)
    return _style(fig, 720)


def equity_chart(trades: pd.DataFrame, title: str = "Résultat cumulé (unités de mise)") -> go.Figure:
    fig = go.Figure()
    if not trades.empty:
        t = trades.sort_values("exit_time")
        fig.add_trace(go.Scatter(x=t["exit_time"], y=t["pnl"].cumsum(), mode="lines",
                                 line=dict(color=VIOLET, width=2), fill="tozeroy",
                                 fillcolor="rgba(139,92,246,0.15)", name="Cumul"))
    fig.update_layout(title=title)
    return _style(fig, 320)


def period_chart(by_period: pd.DataFrame) -> go.Figure:
    fig = go.Figure()
    if not by_period.empty:
        colors = [GREEN if v >= 0 else RED for v in by_period["résultat"]]
        fig.add_trace(go.Bar(x=by_period["période"], y=by_period["résultat"], marker_color=colors))
    fig.update_layout(title="Résultat par période (jeu de test)")
    return _style(fig, 300)

"""Configuration centrale, lue depuis les variables d'environnement (.env)."""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

DEFAULT_SYMBOLS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CAD", "USD/CHF"]
SUPPORTED_INTERVALS = ["1min", "5min", "15min", "30min", "1h", "4h", "1day"]


@dataclass(frozen=True)
class Settings:
    # repr=False : la clé n'apparaît jamais dans les logs ni les affichages.
    twelvedata_api_key: str = field(default="", repr=False)
    max_requests_per_minute: int = 8
    cache_ttl_seconds: int = 60
    request_timeout_seconds: int = 10
    max_stale_candles: int = 3
    log_level: str = "INFO"
    base_url: str = "https://api.twelvedata.com"

    @property
    def has_api_key(self) -> bool:
        return bool(self.twelvedata_api_key.strip()) and "votre_cle" not in self.twelvedata_api_key


def _int_env(name: str, default: int, minimum: int = 1) -> int:
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return max(minimum, int(raw))
    except ValueError:
        logging.getLogger(__name__).warning("Valeur invalide pour %s, défaut utilisé.", name)
        return default


def load_settings() -> Settings:
    load_dotenv()
    return Settings(
        twelvedata_api_key=os.getenv("TWELVEDATA_API_KEY", "").strip(),
        max_requests_per_minute=_int_env("MAX_REQUESTS_PER_MINUTE", 8),
        cache_ttl_seconds=_int_env("CACHE_TTL_SECONDS", 60),
        request_timeout_seconds=_int_env("REQUEST_TIMEOUT_SECONDS", 10),
        max_stale_candles=_int_env("MAX_STALE_CANDLES", 3),
        log_level=os.getenv("LOG_LEVEL", "INFO").upper(),
    )


def configure_logging(level: str = "INFO") -> None:
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )

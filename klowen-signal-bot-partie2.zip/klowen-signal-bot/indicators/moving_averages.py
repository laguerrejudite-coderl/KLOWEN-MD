"""EMA 9 / 21 / 50 et détection de tendance."""
from __future__ import annotations

from typing import Iterable

import numpy as np
import pandas as pd


def ema(close: pd.Series, period: int) -> pd.Series:
    return close.ewm(span=period, adjust=False, min_periods=period).mean().rename(f"ema_{period}")


def add_emas(close: pd.Series, periods: Iterable[int] = (9, 21, 50)) -> pd.DataFrame:
    return pd.concat([ema(close, p) for p in periods], axis=1)


def detect_trend(emas: pd.DataFrame, close: pd.Series, slope_window: int = 5) -> pd.Series:
    """'up' si close > EMA9 > EMA21 > EMA50 et EMA21 croissante ; 'down' si l'inverse ; sinon 'flat'."""
    e9, e21, e50 = emas["ema_9"], emas["ema_21"], emas["ema_50"]
    slope = e21.diff(slope_window)
    up = (close > e9) & (e9 > e21) & (e21 > e50) & (slope > 0)
    down = (close < e9) & (e9 < e21) & (e21 < e50) & (slope < 0)
    valid = e50.notna() & slope.notna()
    trend = pd.Series(np.where(up, "up", np.where(down, "down", "flat")), index=close.index)
    return trend.where(valid, "unknown").rename("trend")

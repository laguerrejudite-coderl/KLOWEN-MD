"""Bandes de Bollinger, ATR, faible volatilité."""
from __future__ import annotations

import numpy as np
import pandas as pd


def bollinger(close: pd.Series, period: int = 20, std: float = 2.0) -> pd.DataFrame:
    mid = close.rolling(period, min_periods=period).mean()
    sd = close.rolling(period, min_periods=period).std(ddof=0)
    upper, lower = mid + std * sd, mid - std * sd
    width = (upper - lower) / mid
    pct_b = (close - lower) / (upper - lower).replace(0, np.nan)
    return pd.DataFrame({"bb_mid": mid, "bb_upper": upper, "bb_lower": lower,
                         "bb_width": width, "bb_pct_b": pct_b})


def atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    prev = close.shift(1)
    tr = pd.concat([high - low, (high - prev).abs(), (low - prev).abs()], axis=1).max(axis=1)
    tr.iloc[0] = high.iloc[0] - low.iloc[0]
    return tr.ewm(alpha=1 / period, adjust=False, min_periods=period).mean().rename(f"atr_{period}")


def low_volatility(atr_series: pd.Series, close: pd.Series, lookback: int = 100,
                   quantile: float = 0.2) -> pd.Series:
    """True quand l'ATR relatif est dans le quantile bas de sa propre histoire récente (sans anticipation)."""
    rel = atr_series / close
    threshold = rel.rolling(lookback, min_periods=lookback // 2).quantile(quantile)
    return (rel <= threshold).where(threshold.notna(), False).rename("low_volatility")


def volatility_level(atr_series: pd.Series, close: pd.Series, lookback: int = 100) -> str:
    """'faible' / 'normale' / 'élevée' d'après le rang percentile de l'ATR relatif actuel."""
    rel = (atr_series / close).dropna().tail(lookback)
    if len(rel) < 20:
        return "inconnue"
    rank = (rel < rel.iloc[-1]).mean()
    return "faible" if rank < 0.25 else "élevée" if rank > 0.75 else "normale"

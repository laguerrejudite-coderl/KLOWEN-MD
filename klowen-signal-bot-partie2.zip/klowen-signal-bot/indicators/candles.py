"""Analyse des chandeliers (ajout à la structure demandée : fichier dédié)."""
from __future__ import annotations

import pandas as pd


def candle_patterns(df: pd.DataFrame, doji_ratio: float = 0.1) -> pd.DataFrame:
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    body = (c - o).abs()
    rng = (h - l).replace(0, float("nan"))
    upper = h - pd.concat([o, c], axis=1).max(axis=1)
    lower = pd.concat([o, c], axis=1).min(axis=1) - l

    doji = (body / rng) <= doji_ratio
    hammer = (lower >= 2 * body) & (upper <= body.clip(lower=1e-12)) & ~doji
    shooting = (upper >= 2 * body) & (lower <= body.clip(lower=1e-12)) & ~doji
    po, pc = o.shift(1), c.shift(1)
    bull_engulf = (pc < po) & (c > o) & (c >= po) & (o <= pc)
    bear_engulf = (pc > po) & (c < o) & (c <= po) & (o >= pc)
    return pd.DataFrame({
        "doji": doji.fillna(False), "hammer": hammer.fillna(False),
        "shooting_star": shooting.fillna(False),
        "bullish_engulfing": bull_engulf.fillna(False),
        "bearish_engulfing": bear_engulf.fillna(False),
    })
